/**
 *
 * @author Juan
 * @descripcion Examen final <3
 */
public class eje2 {
    public static void main(String[] args) {
             String Matricula;
             String Nombre;
             int Edad;
             String DNI;
             TreeSet<Ejercicio2> Matriculas = new TreeSet<>();
             Scanner teclado = new Scanner(System.in);
             Scanner tecladoInt = new Scanner(System.in);

            public eje2(String comprobaciones, String name, int edades, String docidentificativo) {
                this.Matricula = comprobaciones;
                this.Nombre = name;
                this.Edad = edades;
                this.DNI = docidentificativo;
            }

            public static boolean comprobarMatricula(String matriculitasbonitas) {
                Pattern patron = Pattern.compile("[0-9]\\d{9}");
                Matcher checking = patron.matcher(matriculitasbonitas);
                if (checking.find()) {
                    return true;
                }
                return false;
            }

            static void añadirnuevamatricula() {
                String checkeo;
                do {
                    System.out.println("Introduce la Matrícula: ");
                    checkeo = teclado.nextLine();
                    if (!comprobarMatricula(checkeo)) {
                        System.out.println("Matricula Erronea");
                    }
                } while (!revisarMatricula(checkeo));
                System.out.println("Introduce la Matrícula: ");
                String matt = teclado.nextLine();
                System.out.println("Introdusca el Nombre: ");
                String nombreteclado = teclado.nextLine();
                int edad;
                do {
                    System.out.println("Introduce la Edad: ");
                    edad = tecladoInt.nextInt();
                } while (edad > 100 || edad < 16);
                System.out.println("Introduce el DNI: ");
                String nif = teclado.nextLine();
                Matriculas.add(new Ejercicio2(checkeo, nombreteclado, edad, nif));
                System.out.println("Matricula Creada correctamente");

            }
        }